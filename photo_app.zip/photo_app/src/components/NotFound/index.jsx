import React from 'react';

NotFound.propTypes = {};

function NotFound() {
  return (
    <div>
      Oopss ... Not found
    </div>
  );
}

export default NotFound;